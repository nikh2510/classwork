from django.apps import AppConfig


class exampleConfig(AppConfig):
    name = 'example'

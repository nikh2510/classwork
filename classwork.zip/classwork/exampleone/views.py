from django.shortcuts import render

def index(request):
	return render(request,"exampleone/index.html")
def addlogic(request):
	a = request.GET["txtnum1"]
	b = request.GET["txtnum2"]
	c = int(a)+int(b)
	return render(request,"exampleone/index.html",{'r':c})

def fact(request):
    if request.method=="POST":
        num = int(request.POST["txtnum1"])
        s=""
        f=1
        for i in range(num,0,-1):
           f=f*i
           s = "result is "+str(f)
        return render(request,"exampleone/fact.html",{'res':s})
    return render(request,"exampleone/fact.html")

    

def fibo(request):
    if request.method=="POST":
        num = int(request.POST["txtnum"])
        a=-1
        b=1
        #s=""
        s=[]
        for i in range(1,num):
            c=a+b
            #s = s+str(c)
            s.append(c)
            a=b
            b=c
        return render(request,"exampleone/fibo.html",{"res":s})    

    return render(request,"exampleone/fibo.html")    

def si(request):
    if request.method=='POST' and request.POST['btnsubmit']:
        p = request.POST["txtp"]
        r = request.POST["txtr"]
        t = request.POST["txtt"]
        si = (float(p)*float(r)*float(t))/100
        return render(request,"exampleone/si.html",{'res':si,'p1':p,'r1':r,'t1':t})
    return render(request,"exampleone/si.html")


def marksheet(request):
    if request.method=='POST':
        mark = {"PHYSICS":int(request.POST["txtnum1"]),"CHEMISTRY":int(request.POST["txtnum2"]),"MATHS":int(request.POST["txtnum3"]),"HINDI":int(request.POST["txtnum4"]),"ENGLISH":int(request.POST["txtnum5"])}
        flag = True
        total = 0
        sub =" "
        dist = " "
        result = " "
        c=0
        for m in mark:
            if mark.get(m)<0 or mark.get(m)>100:
                result = "All Subject marks should be between 0  to 100"
                break
            elif mark.get(m)<33:
                c=c+1
                sub = sub + m.get
            elif mark.get(m)>75:
                dist = dist + m
            total = total + mark.get(m)
        else:
            if c==0:
                per = total/5
                if per>33 and per<45:
                    result = "Pass with third division"
                elif per<60:
                    result = "Pass with second division"
                else:
                    result = "Pass with first division"
            elif c==1:
                result = "Suppl"
            else:
                result = "Fail"
        return render(request,"exampleone/marksheet.html",{"key":result})
    return render(request,"exampleone/marksheet.html")

from django.urls import path

from .import views

urlpatterns=[

		path('',views.index,name='index'),

		path('addition',views.addition,name="addition"),
		path('addlogic',views.addlogic,name='addlogic'),

		path('prime',views.prime,name="prime"),
		path('primelogic',views.primelogic,name='primelogic'),

		path('middle',views.middle,name="middle"),
		path('middlelogic',views.middlelogic,name='middlelogic'),


		path('addlogiccsrf',views.addlogiccsrf,name='addlogiccsrf'),
		path('additioncsrf',views.additioncsrf,name="additioncsrf"),

		path('primelogiccsrf',views.primelogiccsrf,name='primelogiccsrf'),
		path('primecsrf',views.primecsrf,name="primecsrf"),

		path('middlelogiccsrf',views.middlelogiccsrf,name='middlelogiccsrf'),
		path('middlecsrf',views.middlecsrf,name="middlecsrf"),

		path('fibologic',views.fibologic,name='fibologic'),
		path('fibo',views.fibo,name="fibo"),

		path('looplogic1',views.looplogic1,name='looplogic1'),
		path('loop1',views.loop1,name="loop1"),


		path('looplogic2',views.looplogic2,name='looplogic2'),
		path('loop2',views.loop2,name="loop2"),

]
from django.apps import AppConfig


class ExampleoneConfig(AppConfig):
    name = 'exampleone'

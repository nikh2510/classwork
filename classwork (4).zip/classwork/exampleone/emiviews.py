from django.shortcuts import render
from django.views import View


class Emicalc(View):
    def post(self,request):
        p = int(request.POST["amount"])
        i = float(request.POST["interest"])
        t = int(request.POST["tenure"])
        emi = (p * i )/t
        return render(request,"exampleone/emicalc.html",{'emit':emi})

    def get(self,request):
        return render(request,"exampleone/emicalc.html")

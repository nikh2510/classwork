from django.shortcuts import render

def index(request):
	return render(request,"exampleone/index.html")
def addlogic(request):
	a = request.GET["txtnum1"]
	b = request.GET["txtnum2"]
	c = int(a)+int(b)
	return render(request,"exampleone/index.html",{'r':c})

def fact(request):
    if request.method=="POST":
        num = int(request.POST["txtnum1"])
        s=""
        f=1
        for i in range(num,0,-1):
           f=f*i
           s = "result is "+str(f)
        return render(request,"exampleone/fact.html",{'res':s})
    return render(request,"exampleone/fact.html")

    

def fibo(request):
    if request.method=="POST":
        num = int(request.POST["txtnum"])
        a=-1
        b=1
        #s=""
        s=[]
        for i in range(1,num):
            c=a+b
            #s = s+str(c)
            s.append(c)
            a=b
            b=c
        return render(request,"exampleone/fibo.html",{"res":s})    

    return render(request,"exampleone/fibo.html")    

def si(request):
    if request.method=='POST' and request.POST['btnsubmit']:
        p = request.POST["txtp"]
        r = request.POST["txtr"]
        t = request.POST["txtt"]
        si = (float(p)*float(r)*float(t))/100
        return render(request,"exampleone/si.html",{'res':si,'p1':p,'r1':r,'t1':t})
    return render(request,"exampleone/si.html")


def marksheet(request):
    if request.method=='POST':
        mark = {"PHYSICS":int(request.POST["txtnum1"]),"CHEMISTRY":int(request.POST["txtnum2"]),"MATHS":int(request.POST["txtnum3"]),"HINDI":int(request.POST["txtnum4"]),"ENGLISH":int(request.POST["txtnum5"])}
        flag = True
        total = 0
        sub =" "
        dist = " "
        result = " "
        c=0
        for m in mark:
            if mark.get(m)<0 or mark.get(m)>100:
                result = "All Subject marks should be between 0  to 100"
                break
            elif mark.get(m)<33:
                c=c+1
                sub = sub + m.get
            elif mark.get(m)>75:
                dist = dist + m
            total = total + mark.get(m)
        else:
            if c==0:
                per = total/5
                if per>33 and per<45:
                    result = "Pass with third division"
                elif per<60:
                    result = "Pass with second division"
                else:
                    result = "Pass with first division"
            elif c==1:
                result = "Suppl"
            else:
                result = "Fail"
        return render(request,"exampleone/marksheet.html",{"key":result, "m1":request.POST["txtnum1"],"m2":request.POST["txtnum2"],"m3":request.POST["txtnum3"],"m4":request.POST["txtnum4"],"m5":request.POST["txtnum5"],"data":mark})
    return render(request,"exampleone/marksheet.html")


# def feedback(request):
#     if request.method=="POST":
#         name = request.POST["txtname"]
#         gender = request.POST["gender"]
#         course = request.POST.getlist("course[]")
#         branch = request.POST.getlist("branch[]")
#         feed = request.POST["feed"]
#         c = ""
#         for data in course:
#             c= c+data
#             b=""
#             for data in branch:
#                 b = b+data +" "  
#             res = "Name is "+name+ "Gender"+gender+"Courses is "+c+"Branch is"+b+ "Feedback is "+feed
#         return render(request,"exampleone/feedback.html",{"key":res , "gen":gender, "course":course })
#     return render(request,"exampleone/feedback.html")


def areacalc(request):
    if request.method=="POST":
        area = request.POST["area"]
        s=""
        a=""
        z=""
        if area=="triangle":
            b = float(request.POST["val1"])
            h = float(request.POST["val2"])
            a = 1/2 * b * h
            s = "Area of Triangle is "+str(a)
        else:
            l = float(request.POST["val1"])
            b = float(request.POST["val2"])
            z = l * b
            s = "Area of Rectangle is"+str(z)
        return render(request,"exampleone/areacalc.html",{"key":s})
    return render(request,"exampleone/areacalc.html")

def bgcolor(request):
    if request.method=="POST":
        color = request.POST["color"]
        return render(request,"exampleone/bgcolor.html",{"result":color})
    return render(request,"exampleone/bgcolor.html")


def feecalc(request):
    if request.method=="POST":
        courses = request.POST.getlist("course[]")
        advance = request.POST["advance"]
        one=[]; 
        fee=0; 
        valueC=""; 
        k=len(courses)
        for initial in courses:
            if(k==1):
                valueC+=initial;
            else:
                valueC+=initial+", ";
            k-=1;
            if(initial=="ds"):
                fee+=4500;
            elif(initial=="c"):
                fee+=3000;
            elif(initial=="cpp"):
                fee+=4000;
        one+=["Basic Courses : "+valueC]
        if(advance=="pyhton"):
            fee+=35000;
        elif(advance=="java"):
            fee+=40000;
        elif(advance=="net"):
            fee+=20000;
        one+=["Advanced Courses : "+advance]
        one+=["Overall Fee is : "+str(fee)]
        return render(request,"exampleone/feecalc.html",{'data':one,'val':k,'select':courses,'choice':advance})
    return render(request,"exampleone/feecalc.html")




def country(request):
    if request.method=="POST":
        country = request.POST["country"]
        state=[country+"'s State :"]
        if(country=='america'):
            state+=["New York","Atlanta","Washington DC","Chicago","Austin"]
        elif(country=='australia'):
            state+=["Sydney","Melbourne","Brisbane","Perth","Adelaide"]
        elif(country=='china'):
            state+=["Shanghai","Beijing","Tianjin","Shenzhen","Guangzhou"]
        elif(country=='india'):
            state+=["Mumbai","Delhi","Bangalore","Chennai","Pune"]
        elif(country=='russia'):
            state+=["Moscow","St. Petersburg","Novosibirsk","Yekaterinburg","Kazan"]
        else:
            state=["Nothing is there"];
        return render(request,"exampleone/country.html",{'data':state,'choice':country})
        
    return render(request,"exampleone/country.html")


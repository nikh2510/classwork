from django.urls import path
from . import views

urlpatterns=[

path('',views.index,name='index'),
path('addlogic',views.addlogic,name='addlogic'),
path('fact',views.fact,name='fact'),
path('fibo',views.fibo,name='fibo'),
path('si',views.si,name='si'),

path('marksheet',views.marksheet,name='marksheet'),

path('feedback',views.feedback,name='feedback'),

path('areacalc',views.areacalc,name='areacalc'),

path('bgcolor',views.bgcolor,name='bgcolor'),

path('feecalc',views.feecalc,name='feecalc'),

path('country',views.country,name='country'),

path('emicalc',views.emicalc,name='emicalc'),

]
from django.shortcuts import render
from django.http import HttpResponse


# Addition Logic
def index(request):
	return render(request,"example/index.html")
def addition(request):
    return render(request,"example/addition.html")
def addlogic(request):
	a = request.GET["txtnum1"]
	b = request.GET["txtnum2"]
	c = int(a)+int(b)
	return render(request,"example/addition.html",{'r':c})

# Prime Number Logic

def prime(request):
    return render(request,"example/prime.html")
def primelogic(request):
    d = int(request.GET["txtnum3"])
    s=""
    if d > 1:
     
        for i in range(2, int(d/2)+1):
                if (d % i) == 0:
                    s = str(d)+ "is not a prime number"
                    break
        else:
                s = str(d)+"is a prime number"
    else:
        s= str(d)+"is not a prime number"
    return render(request,"example/prime.html",{'f':s})



#Middle Number Logic

def middle(request):
	return render(request,"example/middle.html")
def middlelogic(request):
    f = int(request.GET["txtnum4"])
    x=""
    a= f%10
    f=f//10 
    b=f%10  
    c=f//10   

    if a>b and a<c or a>c and a<b:
    	x=str(a)+" is middle number"
    if b>a and b<c or b>c and b<a:
        x=str(b)+" is middle number"
    if c>a and c<b or c>b and c<a:
        x=str(c)+" is middle number"
    return render(request,"example/middle.html",{'z':x})




# Addition Logic CSRF

def additioncsrf(request):
    return render(request,"example/additioncsrf.html")

def addlogiccsrf(request):
    a = request.POST["txtnum10"]
    b = request.POST["txtnum11"]
    c = int(a)+int(b)
    return render(request,"example/additioncsrf.html",{'p':c})

# Prime Number Logic CSRF

def primecsrf(request):
    return render(request,"example/primecsrf.html")
def primelogiccsrf(request):
    d = int(request.POST["txtnum12"])
    s=""
    if d > 1:
     
        for i in range(2, int(d/2)+1):
                if (d % i) == 0:
                    s = str(d)+ "is not a prime number"
                    break
        else:
                s = str(d)+"is a prime number"
    else:
        s= str(d)+"is not a prime number"
    return render(request,"example/primecsrf.html",{'f':s})



#Middle Number Logic CSRF

def middlecsrf(request):
    return render(request,"example/middlecsrf.html")
def middlelogiccsrf(request):
    f = int(request.POST["txtnum13"])
    x=""
    a= f%10
    f=f//10 
    b=f%10  
    c=f//10   

    if a>b and a<c or a>c and a<b:
        x=str(a)+" is middle number"
    if b>a and b<c or b>c and b<a:
        x=str(b)+" is middle number"
    if c>a and c<b or c>b and c<a:
        x=str(c)+" is middle number"
    return render(request,"example/middlecsrf.html",{'z':x})



def loop1(request):
    return render(request,"example/loop1.html")

def looplogic1(request):
    s=[]
    d=""
    row = int(request.POST["num1"])
    for i in range(row):
        d = (" " * (row*i) + "*" * (i+1))
        s.append(str(d))
    for j in range(row+1):
        d = (" " * (j+2) + "*" * (row*1*j))
        s.append(str(d))
    return render(request, "example/loop1.html",{'loop1result':s})


def loop2(request):
    return render(request,"example/loop2.html")

def looplogic2(request):
    a = int(request.POST["num2"])
    s = ""
    d = ""
    while a!=0:
        s=a%10
        a=a//10
        d=d+str(s)
    return render(request, "example/loop2.html",{'loop2result':s})


def fibo(request):
    return render(request,"example/fibo.html")

def fibologic(request):
    num = int(request.POST["fibo1"])
    f = -1
    d = []
    for i in range(1,num+1):
        c=f+str
        d.append(str(c))
        f=s
        s=c
    return render(request, "example/fibo.html",{'fiboresult':s})